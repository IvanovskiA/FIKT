//Matematika 2
//Programa za presmetuvanje
//na hipotenuza za dadeni kateti
//spored pitagora
#include <iostream>
//Vazen del, sekogas da se dodade koga
//se koristat matematicki funkcii
#include<math.h>
using namespace std;
int main4()
{
    float a,b,c;
    cout<<"Vnesete ja prvata kateta a=";
    cin>>a;
    cout<<"Vnesete ja vtorata kateta b=";
    cin>>b;
    //sqrt() e funckija za presmetuvanje 
    //na kvadraten koren, kako argument
    //go zema brojot cij koren se vadi
    //primer sqrt(9.0)
    c=sqrt(pow(a,2)+pow(b,2));
    //pow(osnova,exponent) e funkcija
    //za stepenuvanje, na primer 2 na 10-ta
    //se pisuva pow(2,10)
    
    cout<<"Dolzinata na hipotenuzata c e "<<c<<endl;
    system("PAUSE");
    return 0;
}
