#include <iostream>
using namespace std;
int main(void)
{ int broj;
  cout<<"Vnesi broj od 1-10 \n";
  cin>>broj;
  switch (broj) // vo zavisnost od vrednosta na promenlivata broj izvrsi nesto
  { case 2: case 4: case 6: case 8: case 10: 
         cout<<"Brojot e paren\n"; break; //ako broj ima vrednost 2,4,6,8,10 pecati Brojot e paren  
    case 1: case 3: case 5: case 7: case 9: 
         cout<<"Brojot e neparen\n"; break; //ako broj ima vrednost 1,3,5,7,9 pecati Brojot e neparen  

    default: 
         cout<<"Brojot ne e od 1-10\n";       //ako broj ne e nitu edno od gorenavedenite,pecati Brojot ne e od 1-10
  }   
  system("PAUSE");
  return 0;
  //switch month
} //main
