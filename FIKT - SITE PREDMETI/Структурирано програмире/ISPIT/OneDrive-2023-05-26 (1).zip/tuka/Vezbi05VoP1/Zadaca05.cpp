/*
Dssp (da se sostavi programa) vo koja korisnikot prvo vnesuva cel broj n
a potoa ke se vnesat n celi broevi. Za kraj da se ispecati zbirot na broevite
*/

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int n=0, i=0;
    int zbir=0;
    cout<<"Vnesete go n, a potoa vnesete tolku broevi. \n";
    cin>>n;
    while(i<n) // blokot na naredbi se izvruva se dodeka uslovot e ispolnet (i e pomalo od 10)
    {
            int x;
            cin>>x;
            zbir+=x;
            i++;
    }
    cout<<zbir<<endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
