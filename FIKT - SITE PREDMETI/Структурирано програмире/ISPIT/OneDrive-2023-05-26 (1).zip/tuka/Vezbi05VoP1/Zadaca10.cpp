/*
Dssp koja od korisnikot ke procita eden broj i ke kazi dali vneseniot broj e prost.
dokolku ne e prost da ispecati kolku broevi go delat bez ostatok i koi se tie.
(ne vklucuvajgi go 1 i samoi toj broj)
*/

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{

   
   int x;
   int deliteli=0;
   cout<<"Vnesi eden broj\n";
   cin>>x;
   for(int i=2;i<=x/2;i++)
   {
           if(x%i==0)
           {
               deliteli++;
               cout<<"brojot "<<i<<" e delitel na brojot "<<x<<endl; //naredba za pecatenje na delitelite
           }
   }
   if(deliteli!=0)
        cout<<"vneseniot broj ne e prost i ima "<<deliteli<<" deliteli\n";
   else
        cout<<"vneseniot broj e prost\n";       
   
   
    system("PAUSE");
    return EXIT_SUCCESS;
}
