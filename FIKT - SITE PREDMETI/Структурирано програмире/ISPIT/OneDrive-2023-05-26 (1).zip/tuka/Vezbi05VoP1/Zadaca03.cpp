/*
Dssp (da se sostavi programa) koja go pecati zbirot na site cifri.

*/

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int i=0;
    int s=0;
    while(i<10) 
    {
            s=s+i;
            i++;
    }
    cout<<s<<endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
