/*
Dssp koj od korisnikot cita broevi se dodeka ne se vnesi negativen broj
i go pecati zbirot na broevite (ne vklucuvajki go negativniot)
*/

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
   int s=0;
   int x;
   cout<<"Vnesi broj\n";
   cin>>x;
   while (x>=0)
   {
         cout<<"Vneseniot broj ne e negativen, vnesi nareden broj\n";
         s+=x;
         cin>>x;
   }
   cout<<"Zbirot na pozitivnite vneseni broevi e "<<s<<endl;
   
   
    system("PAUSE");
    return EXIT_SUCCESS;
}
