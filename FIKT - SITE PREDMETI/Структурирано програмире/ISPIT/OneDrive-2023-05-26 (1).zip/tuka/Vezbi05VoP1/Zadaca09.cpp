/*
Dssp koja od korisnikot ke procita eden broj i ke kazi dali vneseniot broj e prost.
*/

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{

   //Za eden broj da e prost treba toj da se deli samo so 1 i sam so sebe
   //za da proverime dali ima drugi deliteli proveruvame od 2 
   //do polovinata na toj broj (nad polovinata sigurno nema deliteli)
   //kreirame edna boolean promenliva koja na pocetok 
   //ke ni bide false (pretpostavuvame deka brojot e prost)
   //vo for ciklusot proveruvame dali ima broj koj go deli vneseniot broj
   //dokolku ima, boolean promenlivata ja stavame da bide true
   //koga ke zavrsi ciklusot proveruvame dali boolean promenlivata e true ili false
   //dokolku e false sigurni sme deka brojot e prost (nikogas ne se ispolnil uslovot za delivost)
   //dokolku e true sigurni sme deka ima barem eden broj koj go deli vneseniot broj bez ostatok
   int x;
   bool a=false;
   cout<<"Vnesi eden broj\n";
   cin>>x;
   for(int i=2;i<=x/2;i++)
   {
           if(x%i==0)
           {
               a=true;
               break;      
           }
   }
   if(a)
        cout<<"vneseniot broj ne e prost\n";
   else
        cout<<"vneseniot broj e prost\n";       
   
   
    system("PAUSE");
    return EXIT_SUCCESS;
}
