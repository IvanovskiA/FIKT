/*
Dssp (da se sostavi programa) koja na konzola
ke gi pecati cifrite.

*/

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    //for e naredba koja se koristi za povtoruvanje
    //sostavena e od tri dela (koi se oddeleni so tockazapirka ';')
    //vo prviot del najcesto se deklarira i inicijalizira promenlivata za broenje
    //prviot del se izvrsuva samo ednas (na pocetokot)
    //vtoriot del e uslovot i se povtoruva blokot na naredbi se dodeka toj uslov e ispolnet
    //tretiot del se izvrsuva posle sekoe izvrsuvanje na blok naredbite
    //vo tretiot del najcesto se inkrementira promenlivata za broenje
    for(int i=0;i<10;i++)
    {
            cout<<i<<"\n";
    }
    system("PAUSE");
    return EXIT_SUCCESS;
}
