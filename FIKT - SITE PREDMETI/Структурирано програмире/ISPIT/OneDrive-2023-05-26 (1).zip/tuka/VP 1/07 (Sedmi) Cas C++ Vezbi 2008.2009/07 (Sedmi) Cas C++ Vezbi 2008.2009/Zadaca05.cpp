//Da se sostavi programa koja proveruva kolku golemi bukvi 
//sodrzi edena recenica vnesena preku tastatura.
//Recenicata zavrsuva so tocka.
//ASCII kodovite na golemite bukvi se od 65 - 90.
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int i, b=0;
    string recenica;
    cout<<"Vnesete nekoja recenica sto zavrsuva so tocka .\n";
    getline(cin,recenica,'.');
    for(i=0;i<recenica.length();i++){
    if(recenica.at(int(i))>=65&&recenica.at(int(i))<=90)
    b++;
}
cout<<"Recenicata ima "<<b<<" golemi bukvi.\n";
    system("PAUSE");
    return EXIT_SUCCESS;
}
