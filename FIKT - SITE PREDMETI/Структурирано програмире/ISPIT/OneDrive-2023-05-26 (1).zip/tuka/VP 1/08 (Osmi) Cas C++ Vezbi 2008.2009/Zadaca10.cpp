//DSSP koja ke proveruva dali nizata e vo ratsecki redosled.
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int n,zbir=0;
    cin>>n;
    bool a=true;
    int niza[n];
    for(int i=0;i<n;i++)
    {
    cin>>niza[i];
    }
    for(int i=0;i<(n-1);i++)
    {
            
            if(niza[i]>=niza[i+1])
            a=false;
    
    }
    
    if(a)
    cout<<"Nizata e rastecka\n";
    else
    cout<<"Nizata ne e rastecka\n"; 
    system("PAUSE");
    return EXIT_SUCCESS;
}

