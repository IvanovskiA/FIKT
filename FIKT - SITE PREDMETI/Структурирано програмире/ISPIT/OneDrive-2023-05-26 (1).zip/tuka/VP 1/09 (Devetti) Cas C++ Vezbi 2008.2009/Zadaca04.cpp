// DSSP koja vo edna recenica vnesena do tocka proveruva kolku golemi samoglaski ima.
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    string s;
    int b=0;
    getline(cin,s,'.');
    for(int i=0; i<s.length();i++)
    {
     if(s.at(i)=='A'|| s.at(i)=='E'|| s.at(i)=='I'|| s.at(i)=='O'|| s.at(i)=='U')
     b++;    
    }
    cout<<"Recenicata ima "<<b<<" samoglaski.\n";
    system("PAUSE");
    return 0;
}
