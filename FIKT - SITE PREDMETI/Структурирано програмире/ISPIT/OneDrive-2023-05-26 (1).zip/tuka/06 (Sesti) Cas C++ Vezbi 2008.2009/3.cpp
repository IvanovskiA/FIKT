//Dssp sto povikuva dve funkcii. Edanata pecati Hello World, drugata Hi.
#include <cstdlib>
#include <iostream>

using namespace std;

void hello();
void hello1();
int main()
{
    int i;
    for(i=0;i<10;i++)
    {
       hello();  
       hello1();          
    }
    system("PAUSE");
    return 0;
}

void hello()
{
     
   cout<<"Hello World"<<"\n";  
}

void hello1(){
     cout<<"Hi"<<"\n";     
     }
