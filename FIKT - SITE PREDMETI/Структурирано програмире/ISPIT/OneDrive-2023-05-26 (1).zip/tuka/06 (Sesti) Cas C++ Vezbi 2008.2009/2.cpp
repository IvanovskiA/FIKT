//Dssp sto povikuva ista funkcija deset pati, funkcijata pecati Zdravo na site !!!
#include <cstdlib>
#include <iostream>

using namespace std;

void pozdrav(){
        
     cout<<"Zdravo na site !!!"<<"\n";
     
}

int main(int argc, char *argv[])
{
     int i;
     for(i=0;i<10;i++)
     {
     pozdrav();                            
     }      
     
    system("PAUSE");
    return EXIT_SUCCESS;
}


