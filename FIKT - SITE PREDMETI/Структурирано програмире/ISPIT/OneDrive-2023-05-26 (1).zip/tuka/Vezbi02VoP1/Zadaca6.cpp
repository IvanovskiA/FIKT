#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    float x,y;
    cout<<"Vnesete dva broja\n";
    cout<<"x=";
    cin>>x;
    cout<<"y=";
    cin>>y;
    cout<<"x+y="<<x+y<<"\n";
    cout<<"x-y="<<x-y<<"\n";
    cout<<"x*y="<<x*y<<"\n";
    cout<<"x/y="<<x/y<<"\n";
    system("PAUSE");
    return EXIT_SUCCESS;
}
