#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    char c; //Deklaracija na promenliva od tip char (karakter)
    cout<<"Vnesi eden karakter \n";
    cin>>c; //Vnesuvanje na vrednost za promenlivata c preku tastatura
    cout<<"Karakterot koj go vnesovte e:"<<c<<"\n"; //Pecatenje na konzola(ekran) na promenlivata c
    system("PAUSE");
    return EXIT_SUCCESS;
}
