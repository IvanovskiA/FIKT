#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int a=5;
    int b=10;
    cout<<a<<"\n"<<b<<"\n"<<a+b<<"\n";
    system("PAUSE");
    return EXIT_SUCCESS;
}
