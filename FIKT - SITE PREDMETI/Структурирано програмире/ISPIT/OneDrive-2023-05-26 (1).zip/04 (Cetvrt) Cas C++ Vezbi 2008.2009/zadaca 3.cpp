#include <iostream>
using namespace std;
int main(void)
{ char bukva;
  cout<<"Vnesi edna bukva !\n";
  cin>>bukva;
  switch (bukva) // vo zavisnost od vrednosta na promenlivata bukva izvrsi nesto
  { 
    case 'A': case 'E': case 'I': case 'O': case 'U': 
         cout<<"Samoglaska, golema bukva\n"; break; //ako bukva e A E I O ili U, pecati Samoglaska, golema bukva
    case 'a': case 'e': case 'i': case 'o': case 'u': 
         cout<<"Samoglaska, mala bukva\n"; break; //ako bukva e a e i o ili u, pecati Samoglaska, mala bukva   
    default: 
         cout<<"Karakterot ne e samoglaska! \n";       //ako bukva ne e nitu edno od gorenavedenite,pecati Karakterot ne e bukva!
  }   
  system("PAUSE");
  return 0;
  //switch month
} //main
