#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int a;
    cout<<"Vnesete eden cel broj!\n";
    cin>>a;
    if(a<100)
    cout<<a*a;
    else
    cout<<a*2;  
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
