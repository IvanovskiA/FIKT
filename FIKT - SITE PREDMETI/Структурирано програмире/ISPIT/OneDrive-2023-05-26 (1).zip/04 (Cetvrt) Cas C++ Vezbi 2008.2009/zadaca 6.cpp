#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int x,y,z;
    cout<<"Vnesete tri celi broevi!\n";
    cin>>x>>y>>z;
    if(x==y&&y==z)
    cout<<"Site broevi se ednakvi!\n";    
    else
    {
     if(y==z)
     cout<<"Vtoriot i tretiot broj se ednakvi!\n";
     else
         {
        if(x==z)
        cout<<"Prviot i tretiot broj se ednakvi!\n";
        else
               {
            if(x==y)
            cout<<"Prviot i vtoriot broj se ednakvi!\n";
            else
            cout<<"Site broevi se razlicni!\n";
                }
            }
     }
             
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
