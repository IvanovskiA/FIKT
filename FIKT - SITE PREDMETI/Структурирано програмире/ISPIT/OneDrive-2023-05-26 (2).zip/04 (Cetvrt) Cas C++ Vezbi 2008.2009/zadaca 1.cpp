#include <iostream>
using namespace std;
int main(void)
{ 
  int den;
  cout<<"Vnesi broj na den vo nedelata !\n";
  cin>>den;
  switch (den) // vo zavisnost od vrednosta na promenlivata den, izvrsi nesto
  { 
    case 1:
         cout<<"Ponedelnik\n"; break; //ako vrednosta na den e 1, pecati Ponedelnik
    case 2:
         cout<<"Vtornik\n"; break; //ako vrednosta na den e 2, pecati Vtornik
    case 3:
         cout<<"Sreda\n"; break; //ako vrednosta na den e 3, pecati Sreda
    case 4:
         cout<<"Cetvrtok\n"; break; //ako vrednosta na den e 4, pecati Cetvrtok
    case 5:
         cout<<"Petok\n"; break; //ako vrednosta na den e 5, pecati Petok
    case 6:
         cout<<"Sabota\n"; break; //ako vrednosta na den e 6, pecati Sabota
    case 7:
         cout<<"Nedela\n"; break; //ako vrednosta na den e 7, pecati Nedela  
    default:
         cout<<"Ne postoi takov broj za den vo nedelata !\n"; break; 
         //ako vrednosta na den ne e nitu edna od gorenavedenite, pecati Ne postoi takov broj za den vo nedelata !         
  }   
  system("PAUSE"); 
  return 0;
  //switch month
} //main
