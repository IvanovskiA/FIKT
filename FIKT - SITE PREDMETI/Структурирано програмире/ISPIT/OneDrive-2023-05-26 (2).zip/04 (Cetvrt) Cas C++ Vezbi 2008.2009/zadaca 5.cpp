#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int x;
    cout<<"Vnesete eden cel broj!\n";
    cin>>x;
    if(x%5==0)
    cout<<"Brojot e deliv so 5!\n";
    else
    cout<<"Brojot ne e deliv so 5!\n";
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
