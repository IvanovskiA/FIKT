#include <iostream>
//Vazen del, sekogas da se dodade koga
//se koristat matematicki funkcii
#include<math.h>
using namespace std;
int main()
{
    float a;
    cout<<"Vnesete broj a=";
    cin>>a;    
    cout<<"Sinus od a="<<sin(a)<<"\n";
    cout<<"Kosinus od a="<<cos(a)<<"\n";    
    system("PAUSE");
    return 0;
}
