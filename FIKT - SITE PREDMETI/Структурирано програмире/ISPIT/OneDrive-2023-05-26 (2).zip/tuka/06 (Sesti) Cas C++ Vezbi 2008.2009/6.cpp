//Dssp sto povikuva funkcija koja proveruva dali eden broj e prost ili ne.
#include <cstdlib>
#include <iostream>

using namespace std;

void prost_broj(int x)
{
     bool a;
  for(int i=2;i<=x/2;i++)
   {
           if(x%i==0)
           {
               a=true;
               break;      
           }
   }
   if(a)
        cout<<"vneseniot broj ne e prost\n";
   else
        cout<<"vneseniot broj e prost\n";       
}
   
int main()
{
   prost_broj(17);
   system("PAUSE");
}
