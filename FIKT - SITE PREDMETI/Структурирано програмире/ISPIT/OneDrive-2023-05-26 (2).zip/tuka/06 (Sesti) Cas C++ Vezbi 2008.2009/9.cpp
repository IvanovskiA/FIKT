//Dssp sto povikuva funkcija spored vnesen karakter.
//Ako karakterot e *, se povikuva funkcija koja mnozi dva broja.
//Ako karakterot e /, se povikuva funkcija koja deli dva broja.
#include <cstdlib>
#include <iostream>

using namespace std;

float x;
float y;

float mnozenje()
{
   cin>>x>>y;
   return (x*y);
}

float delenje()
{  
   cin>>x>>y;
   return (x/y);
}

int main()
{   
    float z;
    char znak;
    cout<<"Vnesete znak * ako sakate da pomnozite 2 broja\nili znak / ako sakate da podelite 2 broja\n";
    cin>>znak;
    switch (znak)
    {
           case '*':
                cout<<"Vnesete gi dvata broja sto gi mnozite\n";
                z=mnozenje();
                cout<<z<<"\n";
                break;
           case '/':
                cout<<"Vnesete gi dvata broja sto gi delite\n";
                z=delenje();
                cout<<z<<"\n";
                break;
           default:
                cout<<"Vnesen e pogresen znak !\n";
                break;
    }
    
   system("PAUSE");
}
