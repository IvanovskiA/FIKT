//Dssp sto povikuva funkcija koja ima dva argumenti od tip cel broj i gi sobira.
#include <cstdlib>
#include <iostream>

using namespace std;

int soberi(int a, int b)
{
   int r;
   r=a+b;
   return (r);
}

int main()
{
    int zbir;
    zbir=soberi(4,5);    
    cout<<zbir<<"\n";
    system("PAUSE");
    return 0;
}


