//Dssp sto povikuva funkcija koja pecati Zdravo na site !!!
#include <cstdlib>
#include <iostream>

using namespace std;

void pozdrav(){
     cout<<"Zdravo na site !!!"<<"\n";
     
}

int main(int argc, char *argv[])
{
    pozdrav();    
    system("PAUSE");
    return EXIT_SUCCESS;
}


