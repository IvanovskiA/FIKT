//Dssp sto povikuva dve funkcii.
//Ednata proveruva dali vnesen broj e paren.
//Drugata proveruva za istiot broj dali e deliv so 3.
#include <cstdlib>
#include <iostream>

using namespace std;

int x;

void paren_broj()
{
   cin>>x;
   if(x%2==0)
   cout<<"Brojot e paren\n";
    else
   cout<<"Brojot ne e paren\n";
}

void broj_deliv_so_3(){
  
   if(x%3==0)
   cout<<"Brojot e deliv so 3\n";
    else
   cout<<"Brojot ne e deliv so 3\n";
}

int main()
{
    paren_broj();
    broj_deliv_so_3();

   system("PAUSE");
}
