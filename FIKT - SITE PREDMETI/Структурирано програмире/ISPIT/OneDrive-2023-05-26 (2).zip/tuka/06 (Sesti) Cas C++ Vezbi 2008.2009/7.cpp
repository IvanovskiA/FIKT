//Dssp sto ja povikuva funkcijata za presmetka na prost broj 5 pati (za 5 broevi).
#include <cstdlib>
#include <iostream>

using namespace std;

void prost_broj()
{
     int x;
     cin>>x;
     bool a;
  for(int i=2;i<=x/2;i++)
   {
           if(x%i==0)
           {
               a=true;
               break;      
           }
   }
   if(a)
        cout<<"vneseniot broj ne e prost\n";
   else
        cout<<"vneseniot broj e prost\n";       
}
   
int main()
{
    int i;
   for (i=0;i<5;i++){
   prost_broj();
}
   system("PAUSE");
}
