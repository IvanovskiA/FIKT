/*
Dssp (da se sostavi programa) vo koja korisnikot prvo vnesuva cel broj n
a potoa ke se vnesat n celi broevi. Za kraj da se ispecati proizvodot na broevite
*/

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int n=0;
    int proizvod=1;
    cout<<"Vnesete go n, a potoa vnesete tolku broevi. \n";
    cin>>n;
    for(int i=0;i<n;i++)
    {
            int x;
            cin>>x;
            proizvod*=x;
    }
    cout<<proizvod<<endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
