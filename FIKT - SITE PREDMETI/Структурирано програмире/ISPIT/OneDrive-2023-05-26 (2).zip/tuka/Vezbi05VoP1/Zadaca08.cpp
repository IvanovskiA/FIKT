/*
Dssp koj od korisnikot cita broevi se dodeka ne se vnesi negativen broj
i go pecati najgolemiot broj.
*/

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{

   int x;
   cout<<"Vnesi broj\n";
   cin>>x;
   int max=x;
   while (x>=0)
   {
         cout<<"Vneseniot broj ne e negativen, vnesi nareden broj\n";
         cin>>x;
         if(x>max)
         {
                  max=x;
         }
   }
   cout<<"Najgolem od site vneseni broevi e "<<max<<endl;
   
   
    system("PAUSE");
    return EXIT_SUCCESS;
}
