#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    char c; //Deklaracija na promenliva od tip char (karakter)
    cout<<"Vnesi eden karakter \n";
    cin>>c; //Vnesuvanje na vrednost za promenlivata c preku tastatura
    cout<<"ASCII kodot za vneseniot karakter e:"<<(int)c<<"\n"; //Pecatenje ASCII kod na konzola(ekran) na promenlivata c
    system("PAUSE");
    return EXIT_SUCCESS;
}
