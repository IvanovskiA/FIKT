#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int korisnik1, korisnik2, korisnik3;
    cout<<"Korisnik 1, kolku godini imate vie?\n";
    cin>>korisnik1;
    cout<<"Korisnik 2, kolku godini imate vie?\n";
    cin>>korisnik2;
    cout<<"Korisnik 3, kolku godini imate vie?\n";
    cin>>korisnik3;
    cout<<"Korisnik 1 ima "<<korisnik1<<" godini\n";
    cout<<"Korisnik 2 ima "<<korisnik2<<" godini\n";
    cout<<"Korisnik 3 ima "<<korisnik3<<" godini\n";
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
