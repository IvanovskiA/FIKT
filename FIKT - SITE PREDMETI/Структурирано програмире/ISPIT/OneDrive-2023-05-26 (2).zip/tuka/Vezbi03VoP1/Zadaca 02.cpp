#include <cstdlib>
#include <iostream>
#include <math.h>   //Vo bibliotekata math.h ima razni matematicki funkcii

using namespace std;

int main(int argc, char *argv[])
{
    int x=0;
    float y=0;
    cout<<"x=";
    cin>>x;
    y=3*pow(x,2)+34*x-13/45.3;
    cout<<"y=3*pow(x,2)+34*x-13/45.3\n"; // za da ja koristime funkcijata pow(x,2) mora da ni e vklucena bibliotekata math.h
    cout<<"y="<<y<<"\n";
    system("PAUSE");
    return EXIT_SUCCESS;
}
