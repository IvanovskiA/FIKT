#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    bool a,b;
    cin>>a>>b; // 0=False, 1=true
    if(a||b)
    {
            cout<<"Barem eden od uslovite e ispolnet\n";
    }
    else
    {
            cout<<"Dvata uslovi ne se ispolenti\n";
    }
    system("PAUSE");
    return EXIT_SUCCESS;
}
