#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    bool a;
    cin>>a; // 0=False, 1=true	
    if (a) // ova e isto so if(a==true)
    {
          cout<<"Uslovot e ispolnet\n";
          cout<<a<<"\n";
    }
    else
    {
          cout<<"Uslovot ne e ispolnet\n";
          cout<<a<<"\n";
    }
    system("PAUSE");
    return EXIT_SUCCESS;
}
