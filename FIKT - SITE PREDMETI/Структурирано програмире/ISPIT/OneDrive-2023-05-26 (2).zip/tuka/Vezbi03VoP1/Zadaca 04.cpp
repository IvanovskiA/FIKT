#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int x=0,y=0;
    cout<<"Vnesete dva broja\n";
    cin>>x>>y;
    if(x>y)
    {
           cout<<"Prviot broj e pogolem od vtoriot\n";
    }
    else
    {
           cout<<"Prviot broj ne e pogolem od vtoriot\n";
    }       
    system("PAUSE");
    return EXIT_SUCCESS;
}
