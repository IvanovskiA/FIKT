#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    bool a,b;
    cin>>a>>b; // 0=False, 1=true
    if(a&&b)
    {
            cout<<"Dvata uslovi se ispoleniti\n";
    }
    else
    {
            cout<<"Barem eden od uslovite ne e ispolent\n";
    }

    
    system("PAUSE");
    return EXIT_SUCCESS;
}
