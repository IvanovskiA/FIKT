//DSSP koja cita 10 broevi od niza a potoa gi pecati istite.
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int niza[10];
    for(int i=0;i<10;i++)
    {
    cin>>niza[i];
    }
    
    for(int i=0;i<10;i++)
    {
    cout<<niza[i]<<endl;
    }
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
