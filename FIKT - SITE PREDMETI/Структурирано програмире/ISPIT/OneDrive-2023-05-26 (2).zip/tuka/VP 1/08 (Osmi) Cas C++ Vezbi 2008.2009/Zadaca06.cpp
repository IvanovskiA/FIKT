//DSSP koja ke cita niza od 5 elementi, site elementi gi zgolemuva za 2 i potoa gi pecati.
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int niza[5];
    for(int i=0;i<5;i++)
    {
    cin>>niza[i];
    }
    
    for(int i=0;i<5;i++)
    {
    niza[i]=niza[i]+2;
    }
    
    for(int i=0;i<5;i++)
    {
    cout<<niza[i]<<endl;
    }
    
    system("PAUSE");
    return EXIT_SUCCESS;
}

