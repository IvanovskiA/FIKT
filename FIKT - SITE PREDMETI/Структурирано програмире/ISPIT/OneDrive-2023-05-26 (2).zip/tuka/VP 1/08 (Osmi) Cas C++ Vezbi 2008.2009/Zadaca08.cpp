//DSSP koja ke cita niza od n elementi i potoa go pecati zbirot na site pozitivni elementi.
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int n,zbir=0;
    cin>>n;
    int niza[n];
    for(int i=0;i<n;i++)
    {
    cin>>niza[i];
    }
    for(int i=0;i<n;i++)
    {
            
            if(niza[i]>0)
            zbir=zbir+niza[i];
    
    }
    cout<<zbir<<endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}

