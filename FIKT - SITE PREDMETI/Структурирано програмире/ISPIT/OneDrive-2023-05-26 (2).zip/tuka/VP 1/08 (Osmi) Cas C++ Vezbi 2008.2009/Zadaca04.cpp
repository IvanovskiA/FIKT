//DSSP koja sto ke ima funkcija sto pecati niza koja ja prima na vlez zaedno so brojot na elementi.
//(brojot na elementi se cita vo glavnata funcija).
#include <cstdlib>
#include <iostream>

using namespace std;

void pecatiNiza(int niza[],int n)
{
    for(int i=0;i<n;i++)
    {
    cout<<niza[i]<<endl;
    }    
}

int main(int argc, char *argv[])
{

    int n;
    cin>>n;
    int niza[n];
    for(int i=0;i<n;i++)
    {
    cin>>niza[i];
    }
    pecatiNiza(niza,n);
    system("PAUSE");
    return EXIT_SUCCESS;
}

