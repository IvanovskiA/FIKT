//Da se sostavi funkcija koja prima tri celi broevi (i,n,s) i potoa presmetuva:
// (s+2)*n + (s+4)*n + ........ + (s+n)*n  
#include <cstdlib>
#include <iostream>

using namespace std;
int izraz(int i, int n, int s);
int main(int argc, char *argv[])
{
      int x,y,z;
      cin>>x>>y>>z;
    cout<<izraz(x,y,z)<<"\n";
    system("PAUSE");
    return EXIT_SUCCESS;
}

int izraz(int i, int n, int s)
{
  int x;
  int rezultat=0;
  for(x=2;x<n;x=x+2)
    {
           rezultat=rezultat+((s+x)*n);         
    }
    return (rezultat);
 }
