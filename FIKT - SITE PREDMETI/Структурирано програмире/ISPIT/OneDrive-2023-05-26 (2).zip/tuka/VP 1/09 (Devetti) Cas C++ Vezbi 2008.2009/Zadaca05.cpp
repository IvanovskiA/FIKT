// Da se sostavi funkcija koja ja presmetuva srednata vrednost na elementite vo edna niza od n elementi.
//Nizata i n gi prima na vlez.
#include <cstdlib>
#include <iostream>

using namespace std;
float prosek(int niza[],int n)
{
    int zbir=0;
    float p=0;
    for(int i=0;i<n;i++)
    {
      zbir=zbir+niza[i];        
    }   
    p=zbir/n; 
    return(p);
}


int main(int argc, char *argv[])
{
    int n;
    cin>>n;
    int niza[n];
    for(int i=0;i<n;i++)
    {
     cin>>niza[i];
    }
    cout<<prosek(niza,n);
    system("PAUSE");
    return 0;
}
