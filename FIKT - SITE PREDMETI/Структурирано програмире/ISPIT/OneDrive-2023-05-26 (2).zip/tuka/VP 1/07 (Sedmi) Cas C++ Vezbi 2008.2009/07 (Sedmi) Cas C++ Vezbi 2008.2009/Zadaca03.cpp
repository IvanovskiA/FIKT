#include <cstdlib>
#include <iostream>
#include <fstream> // Potrebno e da se vklu;i ovaa biblioteka za rabota so datoteki
using namespace std;

int main(int argc, char *argv[])
{
    ofstream outFile; //Kreirame izlezen strim
    outFile.open("File.txt"); //Kazuvame kade (vo koj fajl) ke zapisuvame
    outFile<<"Hello World"; //Pisuvame vo fajlot
    outFile.close(); //Go zatvarame fajlot
    system("PAUSE");
    return EXIT_SUCCESS;
}
