#include <cstdlib>
#include <iostream>
//#include <string>
#include <fstream> // Potrebno e da se vkluci ovaa biblioteka za rabota so datoteki
using namespace std;

int main(int argc, char *argv[])
{
    ifstream in; //Keeirame vlezen strim
    string s;
    in.open("File.txt"); //Kazuvame kade (od koj fajl) ke citame
    while(getline(in,s)) // ovaa e slozena naredba koj sto cita od datodeka se dodeka ima sto da se cita
      cout<<s<<endl; //procitaniot tekst se pecati na konzola
    in.close(); //Go zatvarame fajlot
    system("PAUSE");
    return EXIT_SUCCESS;
}
