//Da se sostavi funkcija koja prima promenliva string i proveruva dali e palindrom ili ne.
#include <cstdlib>
#include <iostream>

using namespace std;
void palindrom(string mirror);
int main(int argc, char *argv[])
{
    palindrom("bob");
    system("PAUSE");
    return EXIT_SUCCESS;
}
void palindrom(string mirror)
{
    int i;
    bool a=true;
    for (i=0;i<mirror.length();i++){
    if(mirror.at(i)!=mirror.at(mirror.length()-(i+1)))
    a=false;
    }
    if(a)
    cout<<"Zborot e palindrom.\n";
    else
    cout<<"Zborot ne e palindrom.\n";     
}
