//Da se kreira nova promenliva od tip string, da se vnesi preku tastatura, i potoa da se pecati.
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    string ime;
    cout<<"Vnesete go vaseto ime... \n";
    cin>>ime;
    cout<<"Zdravo "<<ime<<", kako ste?\n";    
    system("PAUSE");
    return EXIT_SUCCESS;
}
