//DSS funkcija koja vo edna recenica gi naoga site tocki a potoa gi zamenuva so zapirka.
//Recenicata ja prima na vlez.
//Funkcijata go vraka brojot na site zameneti karakteri.
#include <cstdlib>
#include <iostream>

using namespace std;

int recenica (string s)
{
   int b=0;
   for(int i=0;i<s.length();i++)
   {
         if (s.at(i)=='.')
         {
              cout<<',';
              b++;          
         }  
         else
         {
              cout<<s.at(i);
         }
   }
         
         return (b);   
}


int main(int argc, char *argv[])
{
    string s;
    cin>>s;
    cout<<recenica(s)<<endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
