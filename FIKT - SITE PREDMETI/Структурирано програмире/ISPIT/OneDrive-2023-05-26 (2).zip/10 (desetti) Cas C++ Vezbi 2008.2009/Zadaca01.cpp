//DSS funkcija koja presmetuva ( (r+3) * (r+6) * (r+9) * ... * (r+s) ) / n, i na vlez gi prima r,s i n.
#include <cstdlib>
#include <iostream>

using namespace std;

int izraz (int r, int s, int n)
{
    int proizvod=1;
    int rezultat=0;
    for (int i=3;i<=s;i=i+3)
    {
        proizvod=proizvod * (r+i);
    }
        rezultat=proizvod/n;
        return (rezultat);
}

int main(int argc, char *argv[])
{
    int r,s,n;
    cin>>r>>s>>n;
    cout<<izraz(r,s,n)<<endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
