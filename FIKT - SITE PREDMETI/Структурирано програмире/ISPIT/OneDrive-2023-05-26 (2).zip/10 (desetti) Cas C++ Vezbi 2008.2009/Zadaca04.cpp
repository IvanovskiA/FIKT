//DSS funkcija koja za dve recenici vneseni preku tastatura proveruva dali se ednakvi.
#include <cstdlib>
#include <iostream>

using namespace std;
string prva;
string vtora;

void recenica()
{
  bool a=true;
  if (prva.length()!=vtora.length())
  {
  a=false;
  }
  else
  {
      for(int i=0;i<prva.length();i++)
      {
              if(prva.at(i)!=vtora.at(i))
              a=false;
      }      
  }  
  if (a)
  cout<<"Recenicite se ednakvi!\n";
  else
  cout<<"Recenicite se razlicni!\n";
}


int main(int argc, char *argv[])
{
    cin>>prva;
    cin>>vtora;
    recenica();
    system("PAUSE");
    return EXIT_SUCCESS;
}
