//DSSP koj ke cita niza od 10 karakteri a potoa ke go pecati sekoj vtor vo obraten redosled
// (pocnuvajki od posledniot)
#include <cstdlib>
#include <iostream>

using namespace std;


int main(int argc, char *argv[])
{
    char nizaKarakteri[10];
    for(int i=0;i<10;i++)
        cin>>nizaKarakteri[i];
    cout<<endl;    
    for(int i=9;i>0;i-=2)
        cout<<nizaKarakteri[i];
    cout<<endl;    
    system("PAUSE");
    return EXIT_SUCCESS;
}
