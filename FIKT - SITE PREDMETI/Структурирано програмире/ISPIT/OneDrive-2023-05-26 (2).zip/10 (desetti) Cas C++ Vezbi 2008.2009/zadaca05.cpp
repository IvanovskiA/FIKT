// Da se napise funkcija koja proveruva dali vnesen broj e sovrsen
//sovrsen broj e toj sto e ednakov na zbirot na negovite deliteli (ne vklucuvajki go samiot broj)
#include <cstdlib>
#include <iostream>

using namespace std;

void sovrsenFn(int broj)
{
     int s=0;
     for(int i=1;i<=broj/2;i++)
             if(broj%i==0)
                 s+=i;
     if(s==broj)
     {
                cout<<"Brojot "<<broj<<" e sovrsen \n";
     }
     else
     {
                cout<<"Brojot "<<broj<<" ne e sovrsen \n";
     }
}



int main(int argc, char *argv[])
{
    int n;
    cin>>n;
    sovrsenFn(n);
    system("PAUSE");
    return EXIT_SUCCESS;
}
