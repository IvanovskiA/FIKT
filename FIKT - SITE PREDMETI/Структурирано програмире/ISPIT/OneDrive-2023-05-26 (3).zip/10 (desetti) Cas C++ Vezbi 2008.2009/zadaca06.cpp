//Da se sostavi funkcija koja na vlez prima cel broj i ja vraka negovata najgolema cifra
#include <cstdlib>
#include <iostream>

using namespace std;

int najgolemaCifra(int broj)
{
    int najgolemaCifra=0;
    while(broj>0)
    {
        
        int cifra=broj%10;
        if(cifra>najgolemaCifra)
            najgolemaCifra=cifra;
        broj=broj/10;
    }
    return najgolemaCifra;
}

int main(int argc, char *argv[])
{
    int n;
    cin>>n;
    cout<<najgolemaCifra(n);
    system("PAUSE");
    return EXIT_SUCCESS;
}
