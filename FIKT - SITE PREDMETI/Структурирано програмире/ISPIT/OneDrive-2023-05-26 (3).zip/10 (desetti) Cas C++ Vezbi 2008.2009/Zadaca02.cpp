//DSS funkcija koja presmetuva ( (a/5) + (a/10) + (a/15) + ... + (a/b) ) * c, i na vlez gi prima a,b i c.
#include <cstdlib>
#include <iostream>

using namespace std;

float izraz (float a, float b, float c)
{
    float zbir=0;
    float rezultat=0;
    for (int i=5;i<=b;i=i+5)
    {
        zbir=zbir + (a/i);
    }
        rezultat=zbir*c;
        return (rezultat);
}

int main(int argc, char *argv[])
{
    float a,b,c;
    cin>>a>>b>>c;
    cout<<izraz(a,b,c)<<endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
