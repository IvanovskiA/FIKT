#include <iostream>
using namespace std;
int main(void)
{ int mesec;
  cout<<"Vnesi broj na mesec\n";
  cin>>mesec;
  switch (mesec) // vo zavisnost od vrednosta na promenlivata mesec izvrsi nesto
  { case 3: case 4: case 5: 
         cout<<"Prolet\n"; break; //ako mesec e 3,4 ili 5, pecati Prolet
    case 6: case 7: case 8: 
         cout<<"Leto\n"; break;   //ako mesec e 6,7 ili 8, pecati Leto
    case 9: case 10: case 11: 
         cout<<"Esen\n"; break; //ako mesec e 9,10 ili 11, pecati Esen
    case 12: case 1: case 2: 
         cout<<"Zima\n"; break;  //ako mesec e 12,1 ili 2, pecati Zima
    default: 
         cout<<"Ne postoi takov mesec!\n";       //ako mesec ne e nitu edno od gorenavedenite,pecati Zima
  }   
  system("PAUSE");
  return 0;
  //switch month
} //main
