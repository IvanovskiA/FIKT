#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    char bukva;
    cout<<"Vnesete nekoja bukva\n";
    cin>>bukva;
    if(bukva=='a' || bukva=='e' || bukva=='i' || bukva=='o' || bukva=='u')
    cout<<"Samoglaska, mala bukva. \n";    
    else{
         if(bukva=='A' || bukva=='E' || bukva=='I' || bukva=='O' || bukva=='U')
         cout<<"Samoglaska, golema bukva. \n";  
         else{
              cout<<"Karakterot e soglaska ili ne e bukva.\n";
              }  
         }      
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
