#include <cstdlib>
#include <iostream>
#include <math.h>

using namespace std;

int main(int argc, char *argv[])
{
    int a,b,c;
    float d;
    cin>>a>>b>>c;
    d=15*pow(a,6)-10*pow(b,4)-2*pow(c,7)*2+10;
    cout<<d<<"\n";    
    system("PAUSE");
    return EXIT_SUCCESS;
}
