#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    float a,b;    
    cin>>a>>b;
    cout<<a<<"\n"<<b<<"\n"<<a/b;
    system("PAUSE");
    return EXIT_SUCCESS;
}
