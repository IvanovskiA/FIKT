#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int a=5;
    cout<<a<<"\n";
    system("PAUSE");
    return EXIT_SUCCESS;
}
