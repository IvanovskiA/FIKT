//Dssp sto povikuva funkcija koja ima eden argument od tip cel broj 
//i presmetuva nekoj izraz - vo ovoj slucaj :  a*(pow(a,4)  
#include <cstdlib>
#include <iostream>
#include <math.h>

using namespace std;

int izraz(int a)
{
   return (a*pow(a,4));
}

int main()
{
    float rezultat;
    rezultat=izraz(2);    
    cout<<rezultat<<"\n";
    system("PAUSE");
    return 0;
}


