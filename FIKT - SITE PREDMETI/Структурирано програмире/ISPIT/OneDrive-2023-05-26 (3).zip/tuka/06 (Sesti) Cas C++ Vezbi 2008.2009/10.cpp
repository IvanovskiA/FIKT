//Dssp koja povikuva funkcija za presmetka na faktoriel na broj.
#include <iostream>
using namespace std;

float faktoriel (float a)
{
  if (a > 1)
   return (a * faktoriel (a-1));
  else
   return (1);
}

int main ()
{
  long broj;
  cout << "Vnesete eden broj: ";
  cin >> broj;
  cout << broj << "! = " << faktoriel (broj);
  system("PAUSE");
  return 0;
}
