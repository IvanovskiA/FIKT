#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int c; 
    cout<<"Vnesi eden broj od 0 do 255 \n";
    cin>>c; 
    cout<<"ASCII karakterot za vneseniot broj e:"<<(char)c<<"\n"; //Pecatenje ASCII vrednosta za daden kod
    system("PAUSE");
    return EXIT_SUCCESS;
}
