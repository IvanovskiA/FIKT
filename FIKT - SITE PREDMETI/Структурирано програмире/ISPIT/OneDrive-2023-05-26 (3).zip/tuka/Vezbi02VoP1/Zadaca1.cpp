#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    char c; //Deklaracija na promenliva od tip char (karakter)
    c='A';  //Inicijalizacija na promenlivata (so karakterot A vo edinecni navodnici)
    cout<<c<<"\n";
    system("PAUSE");
    return EXIT_SUCCESS;
}
