#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int x,y;
    cout<<"Vnesete dva broja\n";
    cin>>x;
    cin>>y;
    cout<<"Rezultatot od celobrojnoto delenje e:"<<x/y<<"\n";
    cout<<"Ostatokot od celobrojnoto delenje e:"<<x%y<<"\n";
    system("PAUSE");
    return EXIT_SUCCESS;
}
