#include <cstdlib>
#include <iostream>
#include <math.h>   //Vo bibliotekata math.h ima razni matematicki funkcii

using namespace std;

int main(int argc, char *argv[])
{
    int x=0;
    cout<<"x=";
    cin>>x;
    //Za stepenuvan na nekoj broj ja koristime funkcijata pow
    //Za x^2 (na kvadrat) imame pow(x,2), za x^i (x na stepen i) imame pow(x,i)
    //Za da ja koristime funkcijata "pow" mora da ni e vklucena bibliotekata math.h
    cout<<"pow(x,2)="<<pow(x,2)<<"\n"; // pow(x,2)=x*x
    cout<<"pow(x,3)="<<pow(x,3)<<"\n"; // pow(x,3)=x*x*x
    cout<<"pow(x,4)="<<pow(x,4)<<"\n"; // pow(x,4)=x*x*x*x
    cout<<"pow(x,5)="<<pow(x,5)<<"\n"; // pow(x,5)=x*x*x*x*x
    cout<<"\n";
    int i=0;
    cout<<"i=";
    cin>>i;
    cout<<"pow(x,i)="<<pow(x,i)<<"\n"; // pow(x,i)=x*x...*x
    system("PAUSE");
    return EXIT_SUCCESS;
}
