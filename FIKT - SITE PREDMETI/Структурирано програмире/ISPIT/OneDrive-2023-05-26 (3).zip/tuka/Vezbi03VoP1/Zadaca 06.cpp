#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    char x,y;
    cout<<"Vnesete dva karakteri\n";
    cin>>x>>y;
    cout<<"\n";
    cout<<x<<" ima ASCII kod "<<(int)x<<"\n";
    cout<<y<<" ima ASCII kod "<<(int)y<<"\n";
    if(x==y)
    {
          cout<<"Karakterite se isti";  
    }
    else
    {
        if(x>y)
        {
           cout<<"Prviot karakter ima pogolem ASCII kod od vtoriot\n";
        }
        else
        {
           cout<<"Prviot karakter ima pomal ASCII kod od vtoriot\n";
        }       
    }
    system("PAUSE");
    return EXIT_SUCCESS;
}
