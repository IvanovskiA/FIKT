#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int x,y,z,w,max;
    cout<<"Vnesete cetiri broja\n";
    cin>>x>>y>>z>>w;
    if(x>y)
    {
            max=x;
    }
    else
    {
            max=y;
    }
    if(max<z)
    {
            max=z;
    }
    if(max<w)
    {
            max=w;
    }
    cout<<"Najgolem broj e:"<<max<<"\n";
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
