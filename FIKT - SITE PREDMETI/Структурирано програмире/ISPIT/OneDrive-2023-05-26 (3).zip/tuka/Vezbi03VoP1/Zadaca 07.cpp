#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int x,y,z,max;
    cout<<"Vnesete tri broja\n";
    cin>>x>>y>>z;
    if(x>y)
    {
            max=x;
    }
    else
    {
            max=y;
    }
    if(max<z)
    {
            max=z;
    }
    cout<<"Najgolem broj e:"<<max<<"\n";
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
