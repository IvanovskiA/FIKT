/*DSSP koja sto od korisnikot cita recenica
do znakot '.' i istata ja pecati na konzola
i praznite mesta gi zamenuva so znakot '_'*/
#include <iostream>

using namespace std;

int main()
{
    string recenica;
    int i;
    cout<<"Vnesete recenica koja sto zavrsuva so znakot '.'"<<endl;
    getline(cin,recenica,'.');
    
    for(i=0;i<recenica.length();i++)                        
        if(recenica.at(i)==' ')
          recenica.at(i)='_';         
                    else               
          cout<<recenica(i);   
    cout<<endl;
    system("PAUSE");
    return 0;
}
