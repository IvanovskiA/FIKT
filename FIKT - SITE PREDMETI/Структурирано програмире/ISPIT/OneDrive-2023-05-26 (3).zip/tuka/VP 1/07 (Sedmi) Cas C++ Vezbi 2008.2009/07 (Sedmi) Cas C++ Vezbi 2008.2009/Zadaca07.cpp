//Da se sostavi funkcija koja prima dva celi broevi (i,n) i potoa presmetuva:
// (1+n)/n * (2+n)/n * ........ * (i+n)/n  
#include <cstdlib>
#include <iostream>

using namespace std;
int izraz(int i, int n);
int main(int argc, char *argv[])
{
    cout<<izraz(4,1)<<"\n";
    system("PAUSE");
    return EXIT_SUCCESS;
}

int izraz(int i, int n)
{
  int x, rezultat=1;
  for(x=1;x<i;x++)
    {
           rezultat=rezultat*((x+n)/n);         
    }
    return (rezultat);
 }
