//Da se sostavi funkcija koja cita zborovi se dodeka zborovite ne nadminat 30 karakteri.
//Funkcijata na krajot go vraka vkupniot broj na karakteri.
#include <cstdlib>
#include <iostream>

using namespace std;
int funkcija();
int main(int argc, char *argv[])
{
    cout<<"Zbirot na site karakteri e "<<funkcija()<<"\n";
    system("PAUSE");
    return EXIT_SUCCESS;
}

int funkcija()
{
    string novZbor;
    int i=0;
    do{
    cout<<"Vnesete nov zbor.\n";
    cin>>novZbor;
    i=i+novZbor.length();
}
while (i<30);
return (i);
}
