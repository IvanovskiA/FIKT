// DSSP koja vo niza binarno ke prebaruva nekoj element.
#include <cstdlib>
#include <iostream>
int NEMA = -1;
using namespace std;

int BinSearch(int Niza[] , int Cel, int Lo, int Hi) 
{
int Mid;
while ( Lo <= Hi ) {
Mid = ( Lo + Hi ) / 2; // najdi go �sredniot� indeks
if ( Niza[Mid] == Cel ) // proveri za ednakvost
return ( Mid );
else if ( Cel < Niza[Mid] )
Hi = Mid - 1; // prebaraj vo dolnata polovina
else
Lo = Mid + 1; // prebaraj vo gornata polovina
}
return ( NEMA ); // Celta ne e pronajdena
}

int main(int argc, char *argv[])
{
    int niza[10];
    for (int i=0;i<10;i++)
    {
        cin>>niza[i];
    }
    cout<<BinSearch(niza,3,0,9);
    system("PAUSE");
    return EXIT_SUCCESS;
}


