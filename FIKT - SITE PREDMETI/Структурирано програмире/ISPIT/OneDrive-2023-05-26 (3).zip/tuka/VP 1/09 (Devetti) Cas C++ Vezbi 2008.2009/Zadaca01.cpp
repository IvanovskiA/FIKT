// DSSP koja vo niza linearno ke prebaruva nekoj element.
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int niza[10];
    int v, index=-1, i=0;    
    
    cout<<"Vnesi niza od 10 broevi"<<endl;
    
    for(int i=0; i<10; i++)
    {
        cin>>niza[i];
    }
    
    cout<<"Vnesete ja vrednosta koja ja barate"<<endl;
    cin>>v;
    
    while(i<10 && index==-1 )
    {
    if (niza[i]==v)
    index=i;   
    i++; 
    }
    
    if(index!=-1)
    cout<<"Elementot so indeks "<<index<<" ima vrednost "<<v<<endl;
    else
    cout<<"Ne postoi element so takva vrednost."<<endl;
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
