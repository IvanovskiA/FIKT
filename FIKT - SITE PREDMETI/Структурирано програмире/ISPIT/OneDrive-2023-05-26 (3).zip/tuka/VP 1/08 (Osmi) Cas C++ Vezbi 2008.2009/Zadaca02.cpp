//DSSP koja cita n broevi od niza a potoa gi pecati istite.
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int n;
    cin>>n;
    int niza[n];
    for(int i=0;i<n;i++)
    {
    cin>>niza[i];
    }
    
    for(int i=0;i<n;i++)
    {
    cout<<niza[i]<<endl;
    }
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
