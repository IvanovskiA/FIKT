0//DSSP koja ke cita niza od n elementi i potoa go naoga minimumot i go pecati.
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int n;
    int max;
    int max1;
    int proizvod;
    cin>>n;
    int niza[n];
    for(int i=0;i<n;i++)
    {
    cin>>niza[i];
    }
    max=niza[0];
    for(int i=1;i<n;i++)
    {        
    if (niza[i]<max)
    max=niza[i];
    }
    proizvod=max1*niza[0];
    cout<<proizvod<<endl;
    system("PAUSE");
}

