//DSSP koja sto ke ima edna globalna niza so 10 elementi, 
//funkcija koja sto ke ja polni nizata i
//funkcija koja sto ke ja pecati nizata.
#include <cstdlib>
#include <iostream>

using namespace std;

int niza[10];

void pecatiNiza()
{
    for(int i=0;i<10;i++)
    {
    cout<<niza[i]<<endl;
    }    
}

void citajNiza()
{
    for(int i=0;i<10;i++)
    {
    cin>>niza[i];
    }    
}

int main(int argc, char *argv[])
{
    
    citajNiza();
    pecatiNiza();
    system("PAUSE");
    return EXIT_SUCCESS;
}

