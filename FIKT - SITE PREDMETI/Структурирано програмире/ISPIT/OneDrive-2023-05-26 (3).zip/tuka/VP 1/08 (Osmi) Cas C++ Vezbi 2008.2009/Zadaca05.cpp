//DSSP koja ke cita niza od 5 elementi i ke gi pecati vo obraten redosled.
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int niza[5];
    for(int i=0;i<5;i++)
    {
    cin>>niza[i];
    }
   
   for(int i=4;i>=0;i--)
    {
    cout<<niza[i]<<endl;
    }
    system("PAUSE");
    return EXIT_SUCCESS;
}

