#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int x,y,z,min;
    cout<<"Vnesete tri broja\n";
    cin>>x>>y>>z;
    if(x>y)
    {
            min=x;
    }
    else
    {
            min=y;
    }
    if(min>z)
    {
            min=z;
    }
    cout<<"Najgolem broj e:"<<min<<"\n";
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
