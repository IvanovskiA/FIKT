/*
Dssp (da se sostavi programa) koja go pecati zbirot na site cifri.

*/

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int s=0;
    for(int i=0;i<10;i++)
    {
            s=s+i;
    }
    cout<<s<<endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
