/*
Dssp (da se sostavi programa) koja na konzola
ke gi pecati cifrite.

*/

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int i=0;
    while(i<10) // blokot na naredbi se izvruva se dodeka uslovot e ispolnet (i e pomalo od 10)
    {
            cout<<i<<"\n";
            i++;
    }
    system("PAUSE");
    return EXIT_SUCCESS;
}
